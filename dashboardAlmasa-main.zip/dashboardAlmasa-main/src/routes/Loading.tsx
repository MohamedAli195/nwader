const Loading = () => <div className="p-5 text-center">Loading...</div>; // You can customize this

export default Loading